package com.fnafmod.doors;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class AnimatedDoorBlockEntity extends BlockEntity implements GeoBlockEntity {
    private static final RawAnimation OPEN = RawAnimation.begin()
            .then("animation.door.open", Animation.LoopType.PLAY_ONCE).thenLoop("animation.door.idle_open");
    private static final RawAnimation CLOSE = RawAnimation.begin()
            .then("animation.door.close", Animation.LoopType.PLAY_ONCE).thenLoop("animation.door.idle_closed");
    private static final RawAnimation IDLE_CLOSED = RawAnimation.begin().thenLoop("animation.door.idle_closed");
    private static final RawAnimation IDLE_BARRICADED = RawAnimation.begin().thenLoop("animation.door.idle_barricaded");
    private static final RawAnimation REMOVE_BOARDS = RawAnimation.begin()
            .then("animation.door.remove_boards", Animation.LoopType.PLAY_ONCE).thenLoop("animation.door.idle_closed");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private boolean wasOpen = false;
    private boolean wasBarricaded = false;

    public AnimatedDoorBlockEntity(BlockPos pos, BlockState state) {
        super(FnafDoors.DOOR_BE.get(), pos, state);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "door", 0, this::predicate));
    }

    private PlayState predicate(AnimationState<AnimatedDoorBlockEntity> state) {
        BlockState bs = getBlockState();
        boolean open = bs.getValue(BlockStateProperties.OPEN);
        boolean barricaded = bs.hasProperty(BarricadedDoorBlock.BARRICADED) && bs.getValue(BarricadedDoorBlock.BARRICADED);
        if (barricaded) {
            wasBarricaded = true;
            return state.setAndContinue(IDLE_BARRICADED);
        }
        if (open) {
            wasOpen = true;
            wasBarricaded = false;
            return state.setAndContinue(OPEN);
        }
        if (wasBarricaded) return state.setAndContinue(REMOVE_BOARDS);
        return state.setAndContinue(wasOpen ? CLOSE : IDLE_CLOSED);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition.offset(-1, 0, -1), worldPosition.offset(2, 2, 2));
    }
}
