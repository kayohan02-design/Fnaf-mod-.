package com.fnafmod.doors;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.BlockHitResult;

/** Porta tapada com tábuas. Shift + mão vazia arranca as tábuas; depois abre normalmente. */
public class BarricadedDoorBlock extends AnimatedDoorBlock {
    public static final BooleanProperty BARRICADED = BooleanProperty.create("barricaded");

    public BarricadedDoorBlock(String doorId, Properties props) {
        super(doorId, props);
        registerDefaultState(defaultBlockState().setValue(BARRICADED, true));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(BARRICADED);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (state.getValue(BARRICADED)) {
            if (player.isShiftKeyDown() && player.getItemInHand(hand).isEmpty()) {
                BlockPos low = state.getValue(HALF) == DoubleBlockHalf.LOWER ? pos : pos.below();
                setBarricade(level, low, false);
                setBarricade(level, low.above(), false);
                level.playSound(null, low, SoundEvents.WOOD_BREAK, SoundSource.BLOCKS, 1f, 1f);
                if (!level.isClientSide) player.displayClientMessage(Component.translatable("message.fnafmod.boards_removed"), true);
            } else if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.fnafmod.barricaded"), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return super.use(state, level, pos, player, hand, hit);
    }

    private void setBarricade(Level level, BlockPos p, boolean value) {
        BlockState s = level.getBlockState(p);
        if (s.is(this)) level.setBlock(p, s.setValue(BARRICADED, value), 10);
    }
}
