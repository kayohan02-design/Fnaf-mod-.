package com.fnafmod.doors;

public interface DoorLike {
    String doorId();
}
