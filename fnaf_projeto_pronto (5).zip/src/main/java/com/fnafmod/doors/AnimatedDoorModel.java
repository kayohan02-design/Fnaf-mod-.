package com.fnafmod.doors;

import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class AnimatedDoorModel extends GeoModel<AnimatedDoorBlockEntity> {
    private String id(AnimatedDoorBlockEntity be) {
        return ((DoorLike) be.getBlockState().getBlock()).doorId();
    }

    @Override
    public ResourceLocation getModelResource(AnimatedDoorBlockEntity be) {
        return new ResourceLocation(FnafDoors.MODID, "geo/" + id(be) + ".geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(AnimatedDoorBlockEntity be) {
        return new ResourceLocation(FnafDoors.MODID, "textures/block/" + id(be) + ".png");
    }

    @Override
    public ResourceLocation getAnimationResource(AnimatedDoorBlockEntity be) {
        return new ResourceLocation(FnafDoors.MODID, "animations/" + id(be) + ".animation.json");
    }
}
