package com.fnafmod.doors;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class FnafDoors {
    public static final String MODID = "fnafmod";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<BlockEntityType<?>> BE_TYPES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MODID);

    public static final List<String> IDS = List.of("office_door", "sliding_door", "swing_door",
            "maintenance_door", "vault_door", "pirate_curtain");
    public static final Map<String, RegistryObject<Block>> DOORS = new LinkedHashMap<>();

    static {
        for (String id : IDS) {
            RegistryObject<Block> b = BLOCKS.register(id, () -> new AnimatedDoorBlock(id,
                    BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(5f)
                            .sound(SoundType.METAL).noOcclusion()));
            DOORS.put(id, b);
            ITEMS.register(id, () -> new BlockItem(b.get(), new Item.Properties()));
        }
    }

    public static final RegistryObject<BlockEntityType<AnimatedDoorBlockEntity>> DOOR_BE = BE_TYPES.register("door",
            () -> BlockEntityType.Builder.of(AnimatedDoorBlockEntity::new,
                    DOORS.values().stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));

    /** Chame no construtor da sua classe principal: FnafDoors.register(modEventBus); */
    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BE_TYPES.register(bus);
    }
}
