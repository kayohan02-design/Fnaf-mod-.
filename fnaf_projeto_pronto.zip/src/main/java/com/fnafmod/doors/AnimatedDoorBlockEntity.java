package com.fnafmod.doors;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class AnimatedDoorBlockEntity extends BlockEntity implements GeoBlockEntity {
    private static final RawAnimation OPEN = RawAnimation.begin()
            .then("animation.door.open", Animation.LoopType.PLAY_ONCE).thenLoop("animation.door.idle_open");
    private static final RawAnimation CLOSE = RawAnimation.begin()
            .then("animation.door.close", Animation.LoopType.PLAY_ONCE).thenLoop("animation.door.idle_closed");
    private static final RawAnimation IDLE_CLOSED = RawAnimation.begin().thenLoop("animation.door.idle_closed");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private boolean wasOpen = false;

    public AnimatedDoorBlockEntity(BlockPos pos, BlockState state) {
        super(FnafDoors.DOOR_BE.get(), pos, state);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "door", 0, this::predicate));
    }

    private PlayState predicate(AnimationState<AnimatedDoorBlockEntity> state) {
        boolean open = getBlockState().getValue(AnimatedDoorBlock.OPEN);
        if (open) {
            wasOpen = true;
            return state.setAndContinue(OPEN);
        }
        return state.setAndContinue(wasOpen ? CLOSE : IDLE_CLOSED);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition.offset(-1, 0, -1), worldPosition.offset(2, 2, 2));
    }
}
