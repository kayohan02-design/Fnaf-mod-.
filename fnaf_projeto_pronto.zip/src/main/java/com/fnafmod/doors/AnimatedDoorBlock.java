package com.fnafmod.doors;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Porta 1x2 com animação GeckoLib. A metade de baixo tem o BlockEntity; a de cima é invisível. */
public class AnimatedDoorBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;
    public static final EnumProperty<DoubleBlockHalf> HALF = BlockStateProperties.DOUBLE_BLOCK_HALF;

    private static final VoxelShape CLOSED_NS = box(0, 0, 6, 16, 16, 10);
    private static final VoxelShape CLOSED_EW = box(6, 0, 0, 10, 16, 16);
    private static final VoxelShape OPEN_NS = Shapes.or(box(0, 0, 6, 2, 16, 10), box(14, 0, 6, 16, 16, 10));
    private static final VoxelShape OPEN_EW = Shapes.or(box(6, 0, 0, 10, 16, 2), box(6, 0, 14, 10, 16, 16));

    public final String doorId;

    public AnimatedDoorBlock(String doorId, Properties props) {
        super(props);
        this.doorId = doorId;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH)
                .setValue(OPEN, false).setValue(HALF, DoubleBlockHalf.LOWER));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> b) {
        b.add(FACING, OPEN, HALF);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockPos pos = ctx.getClickedPos();
        Level level = ctx.getLevel();
        if (pos.getY() < level.getMaxBuildHeight() - 1 && level.getBlockState(pos.above()).canBeReplaced(ctx)) {
            return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection());
        }
        return null;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        level.setBlock(pos.above(), state.setValue(HALF, DoubleBlockHalf.UPPER), 3);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return state.getValue(HALF) == DoubleBlockHalf.LOWER ? new AnimatedDoorBlockEntity(pos, state) : null;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return state.getValue(HALF) == DoubleBlockHalf.LOWER ? RenderShape.ENTITYBLOCK_ANIMATED : RenderShape.INVISIBLE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        BlockPos low = state.getValue(HALF) == DoubleBlockHalf.LOWER ? pos : pos.below();
        BlockState ls = level.getBlockState(low);
        if (!ls.is(this)) return InteractionResult.PASS;
        boolean open = !ls.getValue(OPEN);
        level.setBlock(low, ls.setValue(OPEN, open), 10);
        BlockState us = level.getBlockState(low.above());
        if (us.is(this)) level.setBlock(low.above(), us.setValue(OPEN, open), 10);
        level.playSound(null, low, open ? SoundEvents.IRON_DOOR_OPEN : SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 1f, 1f);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
        DoubleBlockHalf h = s.getValue(HALF);
        if (d.getAxis() == Direction.Axis.Y && (h == DoubleBlockHalf.LOWER) == (d == Direction.UP)) {
            if (!n.is(this) || n.getValue(HALF) == h) return Blocks.AIR.defaultBlockState();
        }
        return s;
    }

    private VoxelShape shape(BlockState s) {
        boolean ns = s.getValue(FACING).getAxis() == Direction.Axis.Z;
        if (s.getValue(OPEN)) return ns ? OPEN_NS : OPEN_EW;
        return ns ? CLOSED_NS : CLOSED_EW;
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) { return shape(s); }

    @Override
    public VoxelShape getCollisionShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) { return shape(s); }
}
