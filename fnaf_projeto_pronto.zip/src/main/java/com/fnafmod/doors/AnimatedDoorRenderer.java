package com.fnafmod.doors;

import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class AnimatedDoorRenderer extends GeoBlockRenderer<AnimatedDoorBlockEntity> {
    public AnimatedDoorRenderer() {
        super(new AnimatedDoorModel());
    }
}
