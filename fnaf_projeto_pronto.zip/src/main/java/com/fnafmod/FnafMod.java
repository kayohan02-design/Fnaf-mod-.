package com.fnafmod;

import com.fnafmod.doors.FnafDoors;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

@Mod(FnafDoors.MODID)
public class FnafMod {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FnafDoors.MODID);

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("portas",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.fnafmod.portas"))
                    .icon(() -> new ItemStack(FnafDoors.DOORS.get("office_door").get()))
                    .displayItems((params, out) -> FnafDoors.DOORS.values().forEach(b -> out.accept(b.get())))
                    .build());

    public FnafMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        FnafDoors.register(bus);
        TABS.register(bus);
    }
}
